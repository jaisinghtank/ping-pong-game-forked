// // function validateFileExtension(component,msg_id,msg,extns)
// // {
// //    var flag=0;
// //    with(component)
// //    {
// //       var ext=value.substring(value.lastIndexOf('.')+1);
// //       for(i=0;i<extns.length;i++)
// //       {
// //          if(ext==extns[i])
// //          {
// //             flag=0;
// //             break;
// //          }
// //          else
// //          {
// //             flag=1;
// //          }
// //       }
// //       if(flag!=0)
// //       {
// //          document.getElementById(msg_id).innerHTML=msg;
// //          component.value="";
// //          component.style.backgroundColor="#eab1b1";
// //          component.style.border="thin solid #000000";
// //          component.focus();
// //          return false;
// //       }
// //       else
// //       {
// //          return true;
// //       }
// //    }
// // }

// // function validateFileSize(component,maxSize,msg_id,msg)
// // {
// //    if(navigator.appName=="Microsoft Internet Explorer")
// //    {
// //       if(component.value)
// //       {
// //          var oas=new ActiveXObject("Scripting.FileSystemObject");
// //          var e=oas.getFile(component.value);
// //          var size=e.size;
// //       }
// //    }
// //    else
// //    {
// //       if(component.files[0]!=undefined)
// //       {
// //          size = component.files[0].size;
// //       }
// //    }
// //    if(size!=undefined && size>maxSize)
// //    {
// //       document.getElementById(msg_id).innerHTML=msg;
// //       component.value="";
// //       component.style.backgroundColor="#eab1b1";
// //       component.style.border="thin solid #000000";
// //       component.focus();
// //       return false;
// //    }
// //    else
// //    {
// //       return true;
// //    }
// // }
// How Much Text is in a Kilobyte or Megabyte?
// L. S. Wynn
// L. S. Wynn
// Last Modified Date: March 28, 2023
// While the exact amount of text data in a kilobyte (KB) or megabyte (MB) can vary depending on the nature of a document, a kilobyte can hold about half of a page of text, while a megabyte holds about 500 pages of text. Text in a digital file is converted to binary data that indicates letters and numbers through expressions of ones and zeros. Larger files hold more of this data, which in turn is the equivalent of more typed information.


// Binary And Bits
// One megabyte can hold around 500 pages of text, comparable to one thick book.
// One megabyte can hold around 500 pages of text, comparable to one thick book.
// Most modern computers are binary systems and work with bits of data. A bit is the most basic unit of information, which can have two states: usually specified as a 0 or 1. Long strings of these bits can represent most types of information including text, pictures and music. Pure binary information, however, is of little use to people who have not learned to read and write in binary. The binary number 11000101110, for example, is equivalent to 1582.


// Grouping Bits into Bytes
// A tablet computer might have gigabytes of storage, capable of holding thousands of books.
// A tablet computer might have gigabytes of storage, capable of holding thousands of books.
// To help make data more accessible and simplified, groups of bits are joined into bytes; one byte is comprised of 8 bits. A set of 8 bits was chosen because this provides 256 total possibilities, which is sufficient for specifying letters, numbers, spaces, punctuation and other extended characters. This very sentence, for example is composed of 125 bytes because there are 125 letters, digits, spaces and punctuation marks. Keep in mind that this only represents pure text; some word processing programs include other sorts of formatting data, and therefore the file sizes become greater than just the number of characters in the file.


// Is Amazon actually giving you a competitive price? This little known plugin reveals the answer.
// Amounts of Text
// Most Compact Discs hold approximately 750 megabytes of data.
// Most Compact Discs hold approximately 750 megabytes of data.
// A kilobyte is 1,024 bytes, often rounded to 1,000 for simplicity; while a megabyte is 1,048,576 bytes, or around 1 million. It is estimated that a kilobyte can accommodate about one-half of a typewritten page. Therefore, one full page requires about 2 KB. The following chart illustrates the number of bytes in common terms such as kilobyte and megabyte and how much text each can store.


// Name	Number of Bytes	Amount of Text
// Kilobyte (KB)	210 or 1,024	1/2 page
// Megabyte (MB)	220 or 1,048,576	500 pages or 1 thick book
// Gigabyte (GB)	230 or 1,073,741,824	500,000 pages or 1,000 thick books
// Terabyte (TB)	240 or 1,099,511,627,776	1 million thick books
// Petabyte	250 or 1,125,899,906,842,624	180 Libraries of Congress
// Exabyte	260 or 1,152,921,504,606,846,976	180 thousand Libraries of Congress
// Zettabyte	270 or 1,180,591,620,717,411,303,424	180 million Libraries of Congress
// Yottabyte	280 or 1,208,925,819,614,629,174,706,176	180 billion Libraries of Congress

// Library of Congress
// A gigabyte can hold the information equivalent of about 1,000 thick books.
// A gigabyte can hold the information equivalent of about 1,000 thick books.
// The Library of Congress in Washington D.C. is said to be the world's largest library with over 28 million volumes. Numbers listed in the chart above are based on the assumption that the average book has 200 pages. This means that about 28 TB of storage would be required to save a digital backup of the entire Library of Congress.

// Portable Media Storage
// Most Compact Discs (CDs) hold approximately 750 MB, which is roughly equivalent to 375,000 pages of text. Digital Versatile Discs (DVDs) can store 4.7 GB or 2.3 million pages. Blu-Ray discs, can hold 27 GB or 13.5 million pages, which is roughly equivalent to the text contained in 67,500 books. Devices like eReaders and tablet computers often have many gigabytes of storage, making them ideal for carrying thousands of books around.

// You might also Like
// Around The Web
// Sponsored by Revcontent
// Raid Bosses, Craft Gear, & Join Friends in This New Alpha. Download Free!
// World Eternal Online
// Ujjain Mom Exposed: Her 3 Year Self-Made Crorepati Secret
// Daily News
// Nine Kinds of Ancestors You Could Find on Your Family Tree
// Emeril Lagasse Finally Opens Up About His Television Disappearance
// Why Google Workspace for Business is Worth the Upgrade
// Get Dog Food Designed for Your Dog's Health & Happiness
// The Close Relationship Between Stress and Sleep
// Four Easy Tips to Keep Your Kids Safe Online
// Did Your Mom Ever Make the Paper? Search Newspapers.com
// AS FEATURED ON:
// LogoLogoLogoLogoLogoLogoLogoLogo

// Related Articles
// What is an External Hard Drive?
// How Many Letters Are in the World’s Longest Alphabet?
// What is a Gigabyte?
// What is a Quadbit?
// What is the Difference Between Mbps and MBps?
// What is Endianness?
// What is Maximum Segment Size?
// Discussion Comments

// ANON940700MARCH 19, 2014
// You all are absolutely wrong. A kilobyte is 1000 bytes and is absolutely not 1024 bytes. In 1998 the International Electrotechnical Commission (IEC) enacted standards for binary prefixes, specifying the use of kilobyte to strictly denote 1000 bytes and kibibyte to denote 1024 bytes. By 2007, the IEC Standard had been adopted by the IEEE, EU, and NIST and is now part of the International System of Quantities.

// Kilo, Mega, and Giga are all SI base 10 prefixes They represent powers of 10, not powers of 2. These prefixes are used throughout the world and in many fields to refer to the exact same value. The reason why there is so much confusion is because companies and developers like Microsoft refuse to comply with the standard definition of these prefixes. They incorrectly say that a kilobyte is 1024 megabytes.

// Kibi, Mebi, and Gibi are binary prefixes (base 2).

// 1 kilobyte (kB) = 1000 bytes

// 1 kibibyte (kiB) = 1024 bytes

// 1 megabyte (MB) = 1000 bytes

// 1 mebibyte (MiB) = 1024 kibibytes

// Think about it. Assume you had never heard of computers before, but were familiar with measurement systems, like the metric system (meters, kilometers, and centimeters). All of these are base 10 because it is easy for us to visualize powers of 10. The prefix definitions should not just change because we are dealing with computers. That is utterly absurd.

// ANON346266AUGUST 27, 2013
// I have doubts about the conversion of text to no bytes. Explain: the text is raju, so tell me size in bytes.

// ANON344698AUGUST 11, 2013
// Remember that a 200 page book has 400 pages of text. Each page has two sides each containing a "page of text".

// ANON325163MARCH 14, 2013
// @wiesen: Still, I have only 98 Libraries of Congress in a Petabyte.

// 2^50 bytes/petabyte * 1 book/409,600 bytes * 1 Lib of Congress/28,000,000 books = 98.2 Libraries of Congress/Petabyte

// ANON318536FEBRUARY 7, 2013
// How many bits would be needed to represent one item out of a set of eight items?

// ANON307891DECEMBER 7, 2012
// The reason it goes 1024 is because that is how the Binary system is set up. 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024. Each bit doubles the previous. There are 1024 bits in a kilobyte, 1024 kilobytes in a megabyte, 1024 megabytes in a Gigabyte, 1024 gigabytes in a terabyte. This has been IT in the morning. Have a good day.

// WIESENAUGUST 1, 2012
// @anon213298: Your math is off. The table above lists the number of bytes in a petabyte, while your number regarding the amount of data in the Library of Congress is in kb. So you're dividing the petabyte value in bytes by a number in kilobytes, and that's why your result is off.

// ANON268406MAY 14, 2012
// I wonder if you could help understanding how to calculate this.

// Assuming a disc holds 700 MB of data, calculate the number of CDs required to hold 295 exabytes of data. Show your working and round your answer to the nearest whole number of billions (where 1 billion is 1 × 109).

// ANON213298SEPTEMBER 10, 2011
// I've got to question the math here.

// 1 page = 2 kb

// 200 pg book = 400 kb

// Library of congress = 28 million books = 11,200,000,000 kb

// 1 petabyte/28 M books = 100,527

// Therefore, there are more than 100,000 library of congress's in a petabyte, not 180 as stated in the chart. What am I missing?

// CATAPULTFEBRUARY 23, 2011
// I always imagined that a kilobyte contained more data than that. Of course, I also thought that the kilobyte to megabyte ratio went by round numbers like thousands, not 1024. I think this was because it sounds like the metric system. This does explain to me a lot more than I knew before about data, though.

// FERNVALLEYFEBRUARY 22, 2011
// I have to say that I have never understood anything to do with binary before, and now I can see, to some extent at least, how that system works and how it relates to pure data; even more, I feel more curious about it than before now that I understand at least a little.

// Post your comments
// Post Anonymously
// Login:
// User Name
 
// Password
// Forgot password?
// Register:
// User Name
 
// Password
 
// Confirm Password
 